package app.ray.wechatmements.base;

/**
 * Created by Ray on 2017/11/12.
 */

public abstract class BasePresenter {


    protected abstract void onDestroy();
}
