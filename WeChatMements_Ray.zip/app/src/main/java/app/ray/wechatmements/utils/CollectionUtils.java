package app.ray.wechatmements.utils;

import java.util.Collection;

/**
 * Created by Ray on 2017/11/12.
 */

public class CollectionUtils {

    public static boolean isCollectionNullOrEmpty(Collection list) {
        return list == null || list.isEmpty();
    }
}
