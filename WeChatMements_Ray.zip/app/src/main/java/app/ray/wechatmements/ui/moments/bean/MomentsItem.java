package app.ray.wechatmements.ui.moments.bean;

/**
 * Created by Ray on 2017/11/12.
 */

public interface MomentsItem {
}
