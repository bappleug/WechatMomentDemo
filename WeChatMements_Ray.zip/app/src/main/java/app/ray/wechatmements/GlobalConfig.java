package app.ray.wechatmements;

/**
 * Created by Ray on 2017/11/10.
 */

public interface GlobalConfig {


    String TEST_HOST = "http://thoughtworks-ios.herokuapp.com";

}
